package sixteen;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Destabilizer extends Robot {

    Destabilizer(RobotController rc) throws GameActionException {
        super(rc);
    }

    void play(){

    }

}