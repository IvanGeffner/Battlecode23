package fourteen;

public class Constants {

    static String indicatorString;
    static int DEBUG = 0;
    static int DEBUG_BUGPATH = 0;
    static int INF = 1000000000;

}
