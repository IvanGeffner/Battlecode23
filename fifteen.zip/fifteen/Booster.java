package fifteen;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Booster extends Robot {

    Booster(RobotController rc) throws GameActionException {
        super(rc);
    }

    void play(){

    }

}